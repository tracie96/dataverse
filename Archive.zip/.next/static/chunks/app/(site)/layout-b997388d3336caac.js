(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[457],{5502:function(r,l,n){Promise.resolve().then(n.bind(n,1182))},1182:function(r,l,n){"use strict";let d,c;n.r(l),n.d(l,{default:function(){return RootLayout}});var h,m=n(7437),u=n(5697),x=n.n(u),g=n(9844),w=n(6691),v=n.n(w),components_Footer=()=>(0,m.jsx)(m.Fragment,{children:(0,m.jsx)("footer",{className:"border-t border-stroke shadow-lg transition duration-100 bg-white dark:border-strokedark dark:bg-blacksection",children:(0,m.jsxs)("div",{className:"mx-auto max-w-c-1390 px-4 md:px-8 2xl:px-0",children:[(0,m.jsx)("div",{className:"py-20 lg:py-25",children:(0,m.jsxs)("div",{className:"flex flex-wrap gap-8 lg:justify-between lg:gap-0",children:[(0,m.jsxs)(g.E.div,{variants:{hidden:{opacity:0,y:-20},visible:{opacity:1,y:0}},initial:"hidden",whileInView:"visible",transition:{duration:1,delay:.5},viewport:{once:!0},className:"animate_top w-1/2 lg:w-1/4",children:[(0,m.jsxs)("a",{href:"/",className:"relative",style:{width:"70%"},children:[(0,m.jsx)(v(),{src:"/images/logo/logo.png",alt:"logo",width:70.03,height:30,style:{width:"30%"},className:"hidden dark:block py-2"}),(0,m.jsx)(v(),{src:"/images/logo/logo.png",alt:"logo",width:70.03,height:30,style:{width:"30%"},className:"w-full dark:hidden py-2"})]}),(0,m.jsx)("p",{className:"mb-10 mt-5"}),(0,m.jsx)("p",{className:"mb-1.5 text-sectiontitle uppercase tracking-[5px]",children:"contact"}),(0,m.jsx)("a",{href:"#",className:"text-itemtitle font-medium text-black dark:text-white",children:"info@dataverseafrica.org                "})]}),(0,m.jsxs)("div",{className:"flex w-full flex-col gap-8 md:flex-row md:justify-between md:gap-0 lg:w-2/3 xl:w-7/12",children:[(0,m.jsxs)(g.E.div,{variants:{hidden:{opacity:0,y:-20},visible:{opacity:1,y:0}},initial:"hidden",whileInView:"visible",transition:{duration:1,delay:.1},viewport:{once:!0},className:"animate_top",children:[(0,m.jsx)("h4",{className:"mb-9 text-itemtitle2 font-medium text-black dark:text-white",children:"Quick Links"}),(0,m.jsxs)("ul",{children:[(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#",className:"mb-3 inline-block hover:text-primary",children:"Home"})}),(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#",className:"mb-3 inline-block hover:text-primary",children:"Home"})}),(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#",className:"mb-3 inline-block hover:text-primary",children:"Home"})}),(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#",className:"mb-3 inline-block hover:text-primary",children:"Home"})})]})]}),(0,m.jsxs)(g.E.div,{variants:{hidden:{opacity:0,y:-20},visible:{opacity:1,y:0}},initial:"hidden",whileInView:"visible",transition:{duration:1,delay:.1},viewport:{once:!0},className:"animate_top",children:[(0,m.jsx)("h4",{className:"mb-9 text-itemtitle2 font-medium text-black dark:text-white",children:"Home"}),(0,m.jsxs)("ul",{children:[(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#",className:"mb-3 inline-block hover:text-primary",children:"Home"})}),(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#",className:"mb-3 inline-block hover:text-primary",children:"Home"})}),(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#",className:"mb-3 inline-block hover:text-primary",children:"Home"})}),(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#",className:"mb-3 inline-block hover:text-primary",children:"Home"})})]})]}),(0,m.jsxs)(g.E.div,{variants:{hidden:{opacity:0,y:-20},visible:{opacity:1,y:0}},initial:"hidden",whileInView:"visible",transition:{duration:1,delay:.1},viewport:{once:!0},className:"animate_top",children:[(0,m.jsx)("h4",{className:"mb-9 text-itemtitle2 font-medium text-black dark:text-white",children:"Newsletter"}),(0,m.jsx)("p",{className:"mb-4 w-[90%]",children:"Subscribe to receive future updates"}),(0,m.jsx)("form",{action:"#",children:(0,m.jsxs)("div",{className:"relative",children:[(0,m.jsx)("input",{type:"text",placeholder:"Email address",className:"w-full rounded-full border border-stroke px-6 py-3 shadow-solid-11 focus:border-primary focus:outline-none dark:border-strokedark dark:bg-black dark:shadow-none dark:focus:border-primary"}),(0,m.jsx)("button",{"aria-label":"signup to newsletter",className:"absolute right-0 p-4",children:(0,m.jsxs)("svg",{className:"fill-[#757693] hover:fill-primary dark:fill-white",width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[(0,m.jsx)("g",{clipPath:"url(#clip0_48_1487)",children:(0,m.jsx)("path",{d:"M3.1175 1.17318L18.5025 9.63484C18.5678 9.67081 18.6223 9.72365 18.6602 9.78786C18.6982 9.85206 18.7182 9.92527 18.7182 9.99984C18.7182 10.0744 18.6982 10.1476 18.6602 10.2118C18.6223 10.276 18.5678 10.3289 18.5025 10.3648L3.1175 18.8265C3.05406 18.8614 2.98262 18.8792 2.91023 18.8781C2.83783 18.8769 2.76698 18.857 2.70465 18.8201C2.64232 18.7833 2.59066 18.7308 2.55478 18.6679C2.51889 18.6051 2.50001 18.5339 2.5 18.4615V1.53818C2.50001 1.46577 2.51889 1.39462 2.55478 1.33174C2.59066 1.26885 2.64232 1.2164 2.70465 1.17956C2.76698 1.14272 2.83783 1.12275 2.91023 1.12163C2.98262 1.12051 3.05406 1.13828 3.1175 1.17318ZM4.16667 10.8332V16.3473L15.7083 9.99984L4.16667 3.65234V9.16651H8.33333V10.8332H4.16667Z",fill:""})}),(0,m.jsx)("defs",{children:(0,m.jsx)("clipPath",{id:"clip0_48_1487",children:(0,m.jsx)("rect",{width:"20",height:"20",fill:"white"})})})]})})]})})]})]})]})}),(0,m.jsxs)("div",{className:"flex flex-col flex-wrap items-center justify-center gap-5 border-t border-stroke py-7 dark:border-strokedark lg:flex-row lg:justify-between lg:gap-0",children:[(0,m.jsx)(g.E.div,{variants:{hidden:{opacity:0,y:-20},visible:{opacity:1,y:0}},initial:"hidden",whileInView:"visible",transition:{duration:1,delay:.1},viewport:{once:!0},className:"animate_top",children:(0,m.jsxs)("ul",{className:"flex items-center gap-8",children:[(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#",className:"hover:text-primary",children:"English"})}),(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#",className:"hover:text-primary",children:"Privacy Policy"})}),(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#",className:"hover:text-primary",children:"Support"})})]})}),(0,m.jsx)(g.E.div,{variants:{hidden:{opacity:0,y:-20},visible:{opacity:1,y:0}},initial:"hidden",whileInView:"visible",transition:{duration:1,delay:.1},viewport:{once:!0},className:"animate_top",children:(0,m.jsxs)("p",{children:["\xa9 ",new Date().getFullYear()," Dataverse. All rights reserved"]})}),(0,m.jsx)(g.E.div,{variants:{hidden:{opacity:0,y:-20},visible:{opacity:1,y:0}},initial:"hidden",whileInView:"visible",transition:{duration:1,delay:.1},viewport:{once:!0},className:"animate_top",children:(0,m.jsxs)("ul",{className:"flex items-center gap-5",children:[(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#","aria-label":"social icon",children:(0,m.jsxs)("svg",{className:"fill-[#D1D8E0] transition-all duration-300 hover:fill-primary",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[(0,m.jsx)("g",{clipPath:"url(#clip0_48_1499)",children:(0,m.jsx)("path",{d:"M14 13.5H16.5L17.5 9.5H14V7.5C14 6.47 14 5.5 16 5.5H17.5V2.14C17.174 2.097 15.943 2 14.643 2C11.928 2 10 3.657 10 6.7V9.5H7V13.5H10V22H14V13.5Z",fill:""})}),(0,m.jsx)("defs",{children:(0,m.jsx)("clipPath",{id:"clip0_48_1499",children:(0,m.jsx)("rect",{width:"24",height:"24",fill:"white"})})})]})})}),(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#","aria-label":"social icon",children:(0,m.jsxs)("svg",{className:"fill-[#D1D8E0] transition-all duration-300 hover:fill-primary",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[(0,m.jsx)("g",{clipPath:"url(#clip0_48_1502)",children:(0,m.jsx)("path",{d:"M22.162 5.65593C21.3985 5.99362 20.589 6.2154 19.76 6.31393C20.6337 5.79136 21.2877 4.96894 21.6 3.99993C20.78 4.48793 19.881 4.82993 18.944 5.01493C18.3146 4.34151 17.4803 3.89489 16.5709 3.74451C15.6615 3.59413 14.7279 3.74842 13.9153 4.18338C13.1026 4.61834 12.4564 5.30961 12.0771 6.14972C11.6978 6.98983 11.6067 7.93171 11.818 8.82893C10.1551 8.74558 8.52832 8.31345 7.04328 7.56059C5.55823 6.80773 4.24812 5.75098 3.19799 4.45893C2.82628 5.09738 2.63095 5.82315 2.63199 6.56193C2.63199 8.01193 3.36999 9.29293 4.49199 10.0429C3.828 10.022 3.17862 9.84271 2.59799 9.51993V9.57193C2.59819 10.5376 2.93236 11.4735 3.54384 12.221C4.15532 12.9684 5.00647 13.4814 5.95299 13.6729C5.33661 13.84 4.6903 13.8646 4.06299 13.7449C4.32986 14.5762 4.85 15.3031 5.55058 15.824C6.25117 16.345 7.09712 16.6337 7.96999 16.6499C7.10247 17.3313 6.10917 17.8349 5.04687 18.1321C3.98458 18.4293 2.87412 18.5142 1.77899 18.3819C3.69069 19.6114 5.91609 20.2641 8.18899 20.2619C15.882 20.2619 20.089 13.8889 20.089 8.36193C20.089 8.18193 20.084 7.99993 20.076 7.82193C20.8949 7.2301 21.6016 6.49695 22.163 5.65693L22.162 5.65593Z",fill:""})}),(0,m.jsx)("defs",{children:(0,m.jsx)("clipPath",{id:"clip0_48_1502",children:(0,m.jsx)("rect",{width:"24",height:"24",fill:"white"})})})]})})}),(0,m.jsx)("li",{children:(0,m.jsx)("a",{href:"#","aria-label":"social icon",children:(0,m.jsxs)("svg",{className:"fill-[#D1D8E0] transition-all duration-300 hover:fill-primary",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[(0,m.jsx)("g",{clipPath:"url(#clip0_48_1505)",children:(0,m.jsx)("path",{d:"M6.94 5.00002C6.93974 5.53046 6.72877 6.03906 6.35351 6.41394C5.97825 6.78883 5.46944 6.99929 4.939 6.99902C4.40857 6.99876 3.89997 6.78779 3.52508 6.41253C3.1502 6.03727 2.93974 5.52846 2.94 4.99802C2.94027 4.46759 3.15124 3.95899 3.5265 3.5841C3.90176 3.20922 4.41057 2.99876 4.941 2.99902C5.47144 2.99929 5.98004 3.21026 6.35492 3.58552C6.72981 3.96078 6.94027 4.46959 6.94 5.00002ZM7 8.48002H3V21H7V8.48002ZM13.32 8.48002H9.34V21H13.28V14.43C13.28 10.77 18.05 10.43 18.05 14.43V21H22V13.07C22 6.90002 14.94 7.13002 13.28 10.16L13.32 8.48002Z",fill:""})}),(0,m.jsx)("defs",{children:(0,m.jsx)("clipPath",{id:"clip0_48_1505",children:(0,m.jsx)("rect",{width:"24",height:"24",fill:"white"})})})]})})})]})})]})]})})}),k=n(1396),_=n.n(k),N=n(4033),C=n(2265);let E=["light","dark"],H="(prefers-color-scheme: dark)",L="undefined"==typeof window,V=(0,C.createContext)(void 0),O={setTheme:r=>{},themes:[]},y=()=>{var r;return null!==(r=(0,C.useContext)(V))&&void 0!==r?r:O},$=r=>(0,C.useContext)(V)?C.createElement(C.Fragment,null,r.children):C.createElement(f,r),P=["light","dark"],f=({forcedTheme:r,disableTransitionOnChange:l=!1,enableSystem:n=!0,enableColorScheme:d=!0,storageKey:c="theme",themes:h=P,defaultTheme:m=n?"system":"light",attribute:u="data-theme",value:x,children:g,nonce:w})=>{let[v,k]=(0,C.useState)(()=>S(c,m)),[_,N]=(0,C.useState)(()=>S(c)),L=x?Object.values(x):h,O=(0,C.useCallback)(r=>{let c=r;if(!c)return;"system"===r&&n&&(c=p());let h=x?x[c]:c,g=l?b():null,w=document.documentElement;if("class"===u?(w.classList.remove(...L),h&&w.classList.add(h)):h?w.setAttribute(u,h):w.removeAttribute(u),d){let r=E.includes(m)?m:null,l=E.includes(c)?c:r;w.style.colorScheme=l}null==g||g()},[]),A=(0,C.useCallback)(r=>{k(r);try{localStorage.setItem(c,r)}catch(r){}},[r]),F=(0,C.useCallback)(l=>{let d=p(l);N(d),"system"===v&&n&&!r&&O("system")},[v,r]);(0,C.useEffect)(()=>{let r=window.matchMedia(H);return r.addListener(F),F(r),()=>r.removeListener(F)},[F]),(0,C.useEffect)(()=>{let e=r=>{r.key===c&&A(r.newValue||m)};return window.addEventListener("storage",e),()=>window.removeEventListener("storage",e)},[A]),(0,C.useEffect)(()=>{O(null!=r?r:v)},[r,v]);let B=(0,C.useMemo)(()=>({theme:v,setTheme:A,forcedTheme:r,resolvedTheme:"system"===v?_:v,themes:n?[...h,"system"]:h,systemTheme:n?_:void 0}),[v,A,r,_,n,h]);return C.createElement(V.Provider,{value:B},C.createElement(z,{forcedTheme:r,disableTransitionOnChange:l,enableSystem:n,enableColorScheme:d,storageKey:c,themes:h,defaultTheme:m,attribute:u,value:x,children:g,attrs:L,nonce:w}),g)},z=(0,C.memo)(({forcedTheme:r,storageKey:l,attribute:n,enableSystem:d,enableColorScheme:c,defaultTheme:h,value:m,attrs:u,nonce:x})=>{let g="system"===h,w="class"===n?`var d=document.documentElement,c=d.classList;c.remove(${u.map(r=>`'${r}'`).join(",")});`:`var d=document.documentElement,n='${n}',s='setAttribute';`,v=c?E.includes(h)&&h?`if(e==='light'||e==='dark'||!e)d.style.colorScheme=e||'${h}'`:"if(e==='light'||e==='dark')d.style.colorScheme=e":"",$=(r,l=!1,d=!0)=>{let h=m?m[r]:r,u=l?r+"|| ''":`'${h}'`,x="";return c&&d&&!l&&E.includes(r)&&(x+=`d.style.colorScheme = '${r}';`),"class"===n?x+=l||h?`c.add(${u})`:"null":h&&(x+=`d[s](n,${u})`),x},k=r?`!function(){${w}${$(r)}}()`:d?`!function(){try{${w}var e=localStorage.getItem('${l}');if('system'===e||(!e&&${g})){var t='${H}',m=window.matchMedia(t);if(m.media!==t||m.matches){${$("dark")}}else{${$("light")}}}else if(e){${m?`var x=${JSON.stringify(m)};`:""}${$(m?"x[e]":"e",!0)}}${g?"":"else{"+$(h,!1,!1)+"}"}${v}}catch(e){}}()`:`!function(){try{${w}var e=localStorage.getItem('${l}');if(e){${m?`var x=${JSON.stringify(m)};`:""}${$(m?"x[e]":"e",!0)}}else{${$(h,!1,!1)};}${v}}catch(t){}}();`;return C.createElement("script",{nonce:x,dangerouslySetInnerHTML:{__html:k}})},()=>!0),S=(r,l)=>{let n;if(!L){try{n=localStorage.getItem(r)||void 0}catch(r){}return n||l}},b=()=>{let r=document.createElement("style");return r.appendChild(document.createTextNode("*{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}")),document.head.appendChild(r),()=>{window.getComputedStyle(document.body),setTimeout(()=>{document.head.removeChild(r)},1)}},p=r=>(r||(r=window.matchMedia(H)),r.matches?"dark":"light");var Header_ThemeToggler=()=>{let{theme:r,setTheme:l}=y();return(0,m.jsxs)("button",{"aria-label":"theme toggler",onClick:()=>l("dark"===r?"light":"dark"),className:"bg-gray-2 dark:bg-dark-bg absolute right-17 mr-1.5 flex cursor-pointer items-center justify-center rounded-full text-black dark:text-white lg:static",children:[(0,m.jsx)(v(),{src:"/images/icon/icon-moon.svg",alt:"logo",width:21,height:21,className:"dark:hidden"}),(0,m.jsx)(v(),{src:"/images/icon/icon-sun.svg",alt:"logo",width:22,height:22,className:"hidden dark:block"})]})},A=[{id:1,title:"Home",newTab:!1,path:"/"},{id:2,title:"Our Initiative",newTab:!1,path:"/about"},{id:2.1,title:"Event",newTab:!1,path:"/blog"},{id:4,title:"Support",newTab:!1,path:"/support"}],components_Header=()=>{let[r,l]=(0,C.useState)(!1),[n,d]=(0,C.useState)(!1),[c,h]=(0,C.useState)(!1),u=(0,N.usePathname)(),handleStickyMenu=()=>{window.scrollY>=80?h(!0):h(!1)};return(0,C.useEffect)(()=>{window.addEventListener("scroll",handleStickyMenu)}),(0,m.jsx)("header",{className:"fixed left-0 top-0 z-99999 w-full ".concat(c?"bg-white shadow transition duration-100 dark:bg-black":""),children:(0,m.jsxs)("div",{className:"relative mx-auto max-w-c-1390 items-center justify-between px-4 md:px-8 xl:flex 2xl:px-0",children:[(0,m.jsxs)("div",{className:"flex w-full items-center justify-between xl:w-1/4",children:[(0,m.jsxs)("a",{href:"/",children:[(0,m.jsx)(v(),{src:"/images/logo/logo.png",alt:"logo",width:70.03,height:30,style:{width:"70%"},className:"hidden dark:block py-2"}),(0,m.jsx)(v(),{src:"/images/logo/logo.png",alt:"logo",width:70.03,height:30,style:{width:"70%"},className:"w-full dark:hidden py-2"})]}),(0,m.jsx)("button",{"aria-label":"hamburger Toggler",className:"block xl:hidden",onClick:()=>l(!r),children:(0,m.jsxs)("span",{className:"relative block h-5.5 w-5.5 cursor-pointer",children:[(0,m.jsxs)("span",{className:"absolute right-0 block h-full w-full",children:[(0,m.jsx)("span",{className:"relative left-0 top-0 my-1 block h-0.5 rounded-sm bg-black delay-[0] duration-200 ease-in-out dark:bg-white ".concat(r?"w-0":"!w-full delay-300")}),(0,m.jsx)("span",{className:"relative left-0 top-0 my-1 block h-0.5 rounded-sm bg-black delay-150 duration-200 ease-in-out dark:bg-white ".concat(r?"w-0":"delay-400 !w-full")}),(0,m.jsx)("span",{className:"relative left-0 top-0 my-1 block h-0.5 rounded-sm bg-black delay-200 duration-200 ease-in-out dark:bg-white ".concat(r?"w-0":"!w-full delay-500")})]}),(0,m.jsxs)("span",{className:"du-block absolute right-0 h-full w-full rotate-45",children:[(0,m.jsx)("span",{className:"absolute left-2.5 top-0 block h-full w-0.5 rounded-sm bg-black delay-300 duration-200 ease-in-out dark:bg-white ".concat(r?"h-full":"!h-0 delay-[0]")}),(0,m.jsx)("span",{className:"delay-400 absolute left-0 top-2.5 block h-0.5 w-full rounded-sm bg-black duration-200 ease-in-out dark:bg-white ".concat(r?"h-0.5":"!h-0 delay-200")})]})]})})]}),(0,m.jsxs)("div",{className:"invisible h-0 w-full items-center justify-between xl:visible xl:flex xl:h-auto xl:w-full ".concat(r&&"navbar !visible mt-4 h-auto max-h-[400px] rounded-md bg-white p-7.5 shadow-solid-5 dark:bg-blacksection xl:h-auto xl:p-0 xl:shadow-none xl:dark:bg-transparent"),children:[(0,m.jsx)("nav",{children:(0,m.jsx)("ul",{className:"flex flex-col gap-5 xl:flex-row xl:items-center xl:gap-10",children:A.map((r,l)=>(0,m.jsx)("li",{className:r.submenu&&"group relative",children:r.submenu?(0,m.jsxs)(m.Fragment,{children:[(0,m.jsxs)("button",{onClick:()=>d(!n),className:"flex cursor-pointer items-center justify-between gap-3 hover:text-primary",children:[r.title,(0,m.jsx)("span",{children:(0,m.jsx)("svg",{className:"h-3 w-3 cursor-pointer fill-waterloo group-hover:fill-primary",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512",children:(0,m.jsx)("path",{d:"M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"})})})]}),(0,m.jsx)("ul",{className:"dropdown ".concat(n?"flex":""),children:r.submenu.map((r,l)=>(0,m.jsx)("li",{className:"hover:text-primary",children:(0,m.jsx)(_(),{href:r.path||"#",children:r.title})},l))})]}):(0,m.jsx)(_(),{href:"".concat(r.path),className:u===r.path?"text-primary hover:text-primary":"hover:text-primary",children:r.title})},l))})}),(0,m.jsxs)("div",{className:"mt-7 flex items-center gap-6 xl:mt-0",children:[(0,m.jsx)(Header_ThemeToggler,{}),(0,m.jsx)(_(),{href:"https://nextjstemplates.com/templates/solid",className:"flex items-center justify-center rounded-full bg-primary px-7.5 py-2.5 text-regular text-white duration-300 ease-in-out hover:bg-primaryho",children:"Join the Community \uD83D\uDD25"})]})]})]})})},components_Lines=()=>(0,m.jsxs)("div",{className:"fixed left-0 top-0 -z-20 flex h-full w-full items-center justify-around",children:[(0,m.jsx)("span",{className:"flex h-full w-[1px] animate-line1 bg-stroke dark:bg-strokedark"}),(0,m.jsx)("span",{className:"flex h-full w-[1px] animate-line2 bg-stroke dark:bg-strokedark"}),(0,m.jsx)("span",{className:"flex h-full w-[1px] animate-line3 bg-stroke dark:bg-strokedark"})]});function ScrollToTop(){let[r,l]=(0,C.useState)(!1);return(0,C.useEffect)(()=>{let toggleVisibility=()=>{window.scrollY>300?l(!0):l(!1)};return window.addEventListener("scroll",toggleVisibility),()=>window.removeEventListener("scroll",toggleVisibility)},[]),(0,m.jsx)("div",{className:"fixed bottom-8 right-8 z-[99]",children:r&&(0,m.jsxs)("div",{onClick:()=>{window.scrollTo({top:0,behavior:"smooth"})},"aria-label":"scroll to top",className:"hover:shadow-signUp flex h-10 w-10 cursor-pointer items-center justify-center rounded-sm bg-primary text-white shadow-md transition duration-300 ease-in-out hover:bg-opacity-80",children:[(0,m.jsx)("span",{className:"mt-[6px] h-3 w-3 rotate-45 border-l border-t border-white"}),(0,m.jsx)("span",{className:"sr-only",children:"scroll to top"})]})})}n(2853);let F={data:""},t=r=>"object"==typeof window?((r?r.querySelector("#_goober"):window._goober)||Object.assign((r||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:r||F,B=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,R=/\/\*[^]*?\*\/|  +/g,Y=/\n+/g,o=(r,l)=>{let n="",d="",c="";for(let h in r){let m=r[h];"@"==h[0]?"i"==h[1]?n=h+" "+m+";":d+="f"==h[1]?o(m,h):h+"{"+o(m,"k"==h[1]?"":l)+"}":"object"==typeof m?d+=o(m,l?l.replace(/([^,])+/g,r=>h.replace(/(^:.*)|([^,])+/g,l=>/&/.test(l)?l.replace(/&/g,r):r?r+" "+l:l)):h):null!=m&&(h=/^--/.test(h)?h:h.replace(/[A-Z]/g,"-$&").toLowerCase(),c+=o.p?o.p(h,m):h+":"+m+";")}return n+(l&&c?l+"{"+c+"}":c)+d},K={},s=r=>{if("object"==typeof r){let l="";for(let n in r)l+=n+s(r[n]);return l}return r},goober_modern_i=(r,l,n,d,c)=>{var h;let m=s(r),u=K[m]||(K[m]=(r=>{let l=0,n=11;for(;l<r.length;)n=101*n+r.charCodeAt(l++)>>>0;return"go"+n})(m));if(!K[u]){let l=m!==r?r:(r=>{let l,n,d=[{}];for(;l=B.exec(r.replace(R,""));)l[4]?d.shift():l[3]?(n=l[3].replace(Y," ").trim(),d.unshift(d[0][n]=d[0][n]||{})):d[0][l[1]]=l[2].replace(Y," ").trim();return d[0]})(r);K[u]=o(c?{["@keyframes "+u]:l}:l,n?"":"."+u)}let x=n&&K.g?K.g:null;return n&&(K.g=K[u]),h=K[u],x?l.data=l.data.replace(x,h):-1===l.data.indexOf(h)&&(l.data=d?h+l.data:l.data+h),u},goober_modern_p=(r,l,n)=>r.reduce((r,d,c)=>{let h=l[c];if(h&&h.call){let r=h(n),l=r&&r.props&&r.props.className||/^go/.test(r)&&r;h=l?"."+l:r&&"object"==typeof r?r.props?"":o(r,""):!1===r?"":r}return r+d+(null==h?"":h)},"");function goober_modern_u(r){let l=this||{},n=r.call?r(l.p):r;return goober_modern_i(n.unshift?n.raw?goober_modern_p(n,[].slice.call(arguments,1),l.p):n.reduce((r,n)=>Object.assign(r,n&&n.call?n(l.p):n),{}):n,t(l.target),l.g,l.o,l.k)}goober_modern_u.bind({g:1});let U,q,Q,X=goober_modern_u.bind({k:1});function j(r,l){let n=this||{};return function(){let d=arguments;function a(c,h){let m=Object.assign({},c),u=m.className||a.className;n.p=Object.assign({theme:q&&q()},m),n.o=/ *go\d+/.test(u),m.className=goober_modern_u.apply(n,d)+(u?" "+u:""),l&&(m.ref=h);let x=r;return r[0]&&(x=m.as||r,delete m.as),Q&&x[0]&&Q(m),U(x,m)}return l?l(a):a}}var W=r=>"function"==typeof r,T=(r,l)=>W(r)?r(l):r,et=(d=0,()=>(++d).toString()),dist_b=()=>{if(void 0===c&&"u">typeof window){let r=matchMedia("(prefers-reduced-motion: reduce)");c=!r||r.matches}return c},ei=new Map,dist_$=r=>{if(ei.has(r))return;let l=setTimeout(()=>{ei.delete(r),dist_u({type:4,toastId:r})},1e3);ei.set(r,l)},J=r=>{let l=ei.get(r);l&&clearTimeout(l)},dist_v=(r,l)=>{switch(l.type){case 0:return{...r,toasts:[l.toast,...r.toasts].slice(0,20)};case 1:return l.toast.id&&J(l.toast.id),{...r,toasts:r.toasts.map(r=>r.id===l.toast.id?{...r,...l.toast}:r)};case 2:let{toast:n}=l;return r.toasts.find(r=>r.id===n.id)?dist_v(r,{type:1,toast:n}):dist_v(r,{type:0,toast:n});case 3:let{toastId:d}=l;return d?dist_$(d):r.toasts.forEach(r=>{dist_$(r.id)}),{...r,toasts:r.toasts.map(r=>r.id===d||void 0===d?{...r,visible:!1}:r)};case 4:return void 0===l.toastId?{...r,toasts:[]}:{...r,toasts:r.toasts.filter(r=>r.id!==l.toastId)};case 5:return{...r,pausedAt:l.time};case 6:let c=l.time-(r.pausedAt||0);return{...r,pausedAt:void 0,toasts:r.toasts.map(r=>({...r,pauseDuration:r.pauseDuration+c}))}}},ea=[],es={toasts:[],pausedAt:void 0},dist_u=r=>{es=dist_v(es,r),ea.forEach(r=>{r(es)})},er={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},I=(r={})=>{let[l,n]=(0,C.useState)(es);(0,C.useEffect)(()=>(ea.push(n),()=>{let r=ea.indexOf(n);r>-1&&ea.splice(r,1)}),[l]);let d=l.toasts.map(l=>{var n,d;return{...r,...r[l.type],...l,duration:l.duration||(null==(n=r[l.type])?void 0:n.duration)||(null==r?void 0:r.duration)||er[l.type],style:{...r.style,...null==(d=r[l.type])?void 0:d.style,...l.style}}});return{...l,toasts:d}},G=(r,l="blank",n)=>({createdAt:Date.now(),visible:!0,type:l,ariaProps:{role:"status","aria-live":"polite"},message:r,pauseDuration:0,...n,id:(null==n?void 0:n.id)||et()}),dist_h=r=>(l,n)=>{let d=G(l,r,n);return dist_u({type:2,toast:d}),d.id},dist_n=(r,l)=>dist_h("blank")(r,l);dist_n.error=dist_h("error"),dist_n.success=dist_h("success"),dist_n.loading=dist_h("loading"),dist_n.custom=dist_h("custom"),dist_n.dismiss=r=>{dist_u({type:3,toastId:r})},dist_n.remove=r=>dist_u({type:4,toastId:r}),dist_n.promise=(r,l,n)=>{let d=dist_n.loading(l.loading,{...n,...null==n?void 0:n.loading});return r.then(r=>(dist_n.success(T(l.success,r),{id:d,...n,...null==n?void 0:n.success}),r)).catch(r=>{dist_n.error(T(l.error,r),{id:d,...n,...null==n?void 0:n.error})}),r};var Z=(r,l)=>{dist_u({type:1,toast:{id:r,height:l}})},ee=()=>{dist_u({type:5,time:Date.now()})},D=r=>{let{toasts:l,pausedAt:n}=I(r);(0,C.useEffect)(()=>{if(n)return;let r=Date.now(),d=l.map(l=>{if(l.duration===1/0)return;let n=(l.duration||0)+l.pauseDuration-(r-l.createdAt);if(n<0){l.visible&&dist_n.dismiss(l.id);return}return setTimeout(()=>dist_n.dismiss(l.id),n)});return()=>{d.forEach(r=>r&&clearTimeout(r))}},[l,n]);let d=(0,C.useCallback)(()=>{n&&dist_u({type:6,time:Date.now()})},[n]),c=(0,C.useCallback)((r,n)=>{let{reverseOrder:d=!1,gutter:c=8,defaultPosition:h}=n||{},m=l.filter(l=>(l.position||h)===(r.position||h)&&l.height),u=m.findIndex(l=>l.id===r.id),x=m.filter((r,l)=>l<u&&r.visible).length;return m.filter(r=>r.visible).slice(...d?[x+1]:[0,x]).reduce((r,l)=>r+(l.height||0)+c,0)},[l]);return{toasts:l,handlers:{updateHeight:Z,startPause:ee,endPause:d,calculateOffset:c}}},el=X`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,eo=X`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,en=X`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,ed=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${r=>r.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${el} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${eo} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${r=>r.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${en} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,ec=X`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,eh=j("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${r=>r.secondary||"#e0e0e0"};
  border-right-color: ${r=>r.primary||"#616161"};
  animation: ${ec} 1s linear infinite;
`,em=X`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,eu=X`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,ep=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${r=>r.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${em} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${eu} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${r=>r.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,ex=j("div")`
  position: absolute;
`,ef=j("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,eg=X`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,eb=j("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${eg} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,M=({toast:r})=>{let{icon:l,type:n,iconTheme:d}=r;return void 0!==l?"string"==typeof l?C.createElement(eb,null,l):l:"blank"===n?null:C.createElement(ef,null,C.createElement(eh,{...d}),"loading"!==n&&C.createElement(ex,null,"error"===n?C.createElement(ed,{...d}):C.createElement(ep,{...d})))},ye=r=>`
0% {transform: translate3d(0,${-200*r}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,ge=r=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*r}%,-1px) scale(.6); opacity:0;}
`,ey=j("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,ew=j("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Ae=(r,l)=>{let n=r.includes("top")?1:-1,[d,c]=dist_b()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ye(n),ge(n)];return{animation:l?`${X(d)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${X(c)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},ev=C.memo(({toast:r,position:l,style:n,children:d})=>{let c=r.height?Ae(r.position||l||"top-center",r.visible):{opacity:0},h=C.createElement(M,{toast:r}),m=C.createElement(ew,{...r.ariaProps},T(r.message,r));return C.createElement(ey,{className:r.className,style:{...c,...n,...r.style}},"function"==typeof d?d({icon:h,message:m}):C.createElement(C.Fragment,null,h,m))});h=C.createElement,o.p=void 0,U=h,q=void 0,Q=void 0;var Ee=({id:r,className:l,style:n,onHeightUpdate:d,children:c})=>{let h=C.useCallback(l=>{if(l){let i=()=>{d(r,l.getBoundingClientRect().height)};i(),new MutationObserver(i).observe(l,{subtree:!0,childList:!0,characterData:!0})}},[r,d]);return C.createElement("div",{ref:h,className:l,style:n},c)},Re=(r,l)=>{let n=r.includes("top"),d=r.includes("center")?{justifyContent:"center"}:r.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:dist_b()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${l*(n?1:-1)}px)`,...n?{top:0}:{bottom:0},...d}},ej=goober_modern_u`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,Ie=({reverseOrder:r,position:l="top-center",toastOptions:n,gutter:d,children:c,containerStyle:h,containerClassName:m})=>{let{toasts:u,handlers:x}=D(n);return C.createElement("div",{style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...h},className:m,onMouseEnter:x.startPause,onMouseLeave:x.endPause},u.map(n=>{let h=n.position||l,m=Re(h,x.calculateOffset(n,{reverseOrder:r,gutter:d,defaultPosition:l}));return C.createElement(Ee,{id:n.id,key:n.id,onHeightUpdate:x.updateHeight,className:n.visible?ej:"",style:m},"custom"===n.type?T(n.message,n):c?c(n):C.createElement(ev,{toast:n,position:h}))}))},ToastContext=()=>(0,m.jsx)("div",{children:(0,m.jsx)(Ie,{position:"top-center",reverseOrder:!1})});function RootLayout(r){let{children:l}=r;return(0,m.jsx)("html",{lang:"en",suppressHydrationWarning:!0,children:(0,m.jsx)("body",{className:"dark:bg-black ".concat(x().className),children:(0,m.jsxs)($,{enableSystem:!1,attribute:"class",defaultTheme:"light",children:[(0,m.jsx)(components_Lines,{}),(0,m.jsx)(components_Header,{}),(0,m.jsx)(ToastContext,{}),l,(0,m.jsx)(components_Footer,{}),(0,m.jsx)(ScrollToTop,{})]})})})}},2853:function(){},5697:function(r){r.exports={style:{fontFamily:"'__Inter_36bd41', '__Inter_Fallback_36bd41'",fontStyle:"normal"},className:"__className_36bd41"}},1396:function(r,l,n){r.exports=n(8326)},4033:function(r,l,n){r.exports=n(94)}},function(r){r.O(0,[413,486,326,971,472,744],function(){return r(r.s=5502)}),_N_E=r.O()}]);